
              C++ inline

https://blog.csdn.net/BjarneCpp/article/details/76044493
