
本文主要针对有lambda表达式使用和概念的同学

lambda表达式通常和sort排序,智能指针的自定义删除函数等搭配使用,针对Lambda表达式的捕获,有以下重要概念:

[捕获](https://blog.csdn.net/zh379835552/article/details/19542181)
