
*p++ 是先取p的值，然后操作完成后，p指针+1

(*p)++ 是先取p的值，然后p的值+1

*++p 是给p指针+1， 然后访问新指针指向的值

[例子](https://blog.csdn.net/nkd50000/article/details/81135895)
