采用 对称加密 和 非对称加密 结合的方式来保护浏览器和服务端之间的通信安全。
对称加密算法加密数据+非对称加密算法交换密钥+数字证书验证身份=SSL安全

[好文章一](https://www.jianshu.com/p/ffafb98ffdd7)

[好文章二](https://www.jianshu.com/p/e30a8c4fa329)
