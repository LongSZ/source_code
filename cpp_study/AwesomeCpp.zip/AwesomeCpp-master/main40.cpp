decltype(exp)自动根据exp的返回类型来确定类型
  编译器并不实际调用计算exp，只会分析当调用exp发生时它的返回值
auto 根据表达式自动推断类型
