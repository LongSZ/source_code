// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

#if 0
import strcat;
import<cstdio>;

int main()
{
  const bool b{true};

  const auto s = Normalize(b);

  printf("%s\n", s.c_str());
}

#else
int main() {}
#endif