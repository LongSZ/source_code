// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

struct Point {
  int y;
  int x;
  int z;
};

int main()
{
  const Point p1();
}