// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

#include <vector>

int main()
{
  // #A Using std::vector without specifying a type
  const std::vector a{2, 3, 4};
}