// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

int main()
{
  auto x = 2'000'000;   // #A The probably usual digit separation
  auto y = 2'00'00'00;  // #B But we are free
}