// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

#include <vector>

int main()
{
  std::vector<int> v1(35);  // #A Using parentheses
  std::vector<int> v2{35};  // #B Using curly braces
}