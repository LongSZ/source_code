// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

struct Point {  // #A Point is an aggregate
  int y;
  int x;
  int z;
};

const Point p1{.y = 3, .x = 0, .z = 4};

int main() {}