// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

struct CppIsGreat {
  CppIsGreat();
};

CppIsGreat::CppIsGreat()
{
  // assume some large code here
}

int main()
{
  CppIsGreat cppIsGreat{};
}