// Copyright (c) Andreas Fertig.
// SPDX-License-Identifier: MIT

#include <cstddef>

template<typename T>
class Span {
  T*     mData;
  size_t mSize;

public:
  // constructors
};

int main() {}