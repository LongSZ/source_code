# C++20 for Programmers
This repository contains the source code and supporting files associated with our book **C++20 for Programmers**. https://deitel.com/c-plus-plus-20-for-programmers 
    
These files are Copyright 2021 by Deitel & Associates, Inc. and Pearson Education, Inc. All Rights Reserved. 

You may use these files for your personal purposes, but please do not repost them without our express written consent.

If you have any questions, open an issue in the Issues tab or email us: deitel at deitel dot com.

The authors and publisher of this book have used their best efforts in preparing this book. These efforts include the development, research, and testing of the theories and programs to determine their effectiveness. The authors and publisher make no warranty of any kind, expressed or implied, with regard to these programs or to the documentation contained in this book. The authors and publisher shall not be liable in any event for incidental or consequential damages in connection with, or arising out of, the furnishing, performance, or use of these programs.
