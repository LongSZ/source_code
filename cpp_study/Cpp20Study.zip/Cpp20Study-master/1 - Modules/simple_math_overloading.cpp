module simple_math;

int add(int num1, int num2)
{
    return num1 + num2;
}

int add(int num1, int num2, int num3)
{
    return num1 + num2 + num3;
}