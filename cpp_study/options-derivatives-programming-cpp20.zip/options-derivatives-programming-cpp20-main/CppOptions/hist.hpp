//
//  hist.hpp
//  CppOptions
//
//  Created by Carlos Oliveira on 8/8/20.
//  Copyright © 2020 Carlos Oliveira. All rights reserved.
//

#ifndef hist_hpp
#define hist_hpp

#include <stdio.h>

#endif /* hist_hpp */
