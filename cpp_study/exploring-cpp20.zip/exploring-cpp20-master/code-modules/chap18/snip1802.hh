/** @file snip1802.hh */
/** Code Snippet 18-2 */
std::cin.imbue(std::locale::classic());
std::cout.imbue(std::locale::classic());
