#include <string>
int main() {
#include "snip1801.hh"
return okay.size() == 0;
}
