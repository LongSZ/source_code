/** @file snip1803.hh */
/** Code Snippet 18-3 */
std::cout.imbue(std::locale{""});
