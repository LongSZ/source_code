#include <iostream>
#include <locale>
int main() {
#include "snip1803.hh"
}
