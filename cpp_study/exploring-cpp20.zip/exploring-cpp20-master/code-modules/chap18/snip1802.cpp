#include <iostream>
#include <locale>
int main() {
#include "snip1802.hh"
}
