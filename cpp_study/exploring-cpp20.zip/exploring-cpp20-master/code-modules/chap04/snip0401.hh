/** @file snip0401.hh */
/** Code Snippet 4-1 */
std::string empty{};
int zero{};
