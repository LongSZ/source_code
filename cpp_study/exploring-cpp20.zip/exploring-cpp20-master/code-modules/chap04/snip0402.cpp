#include <iostream>
int main() {
#include "snip0402.hh"
std::cout << x << '\n';
}
