/** @file snip0403.hh */
/** Code Snippet 4-3 */
int x(42);
