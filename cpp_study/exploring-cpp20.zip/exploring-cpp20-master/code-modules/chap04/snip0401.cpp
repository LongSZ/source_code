#include <iostream>
#include <string>
int main() {
#include "snip0401.hh"
return zero;
}
