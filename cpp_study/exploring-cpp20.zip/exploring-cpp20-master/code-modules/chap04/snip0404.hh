/** @file snip0404.hh */
/** Code Snippet 4-4 */
std::string str1 = "sample";
std::string str2("sample");
