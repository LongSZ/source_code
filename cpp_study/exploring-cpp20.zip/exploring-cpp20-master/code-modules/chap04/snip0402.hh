/** @file snip0402.hh */
/** Code Snippet 4-2 */
int x = 42;
