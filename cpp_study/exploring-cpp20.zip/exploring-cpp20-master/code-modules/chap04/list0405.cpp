/** @file list0405.cpp */
/** Listing 4-5. Defining and Printing an Empty String */
import <iostream>;
import <string>;

int main()
{
   std::string empty;
   std::cout << "|" << empty << "|\n";
}
