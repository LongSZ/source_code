#include <iostream>
#include <string>
int main() {
#include "snip0404.hh"
std::cout << str1 << str2 << '\n';
}
