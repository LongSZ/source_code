/** @file list0402.cpp */
/** Listing 4-2. Printing a Double-Quote Character */
import <iostream>;

int main()
{
   std::cout << "\"\n";
}
