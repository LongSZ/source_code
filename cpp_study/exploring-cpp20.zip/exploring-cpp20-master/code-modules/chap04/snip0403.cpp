#include <iostream>
int main() {
#include "snip0403.hh"
std::cout << x << '\n';
}
