/** @file list0704.cxx */
/** Listing 7-4. Compute Sum of Integers from 10 to 20 */
import <iostream>;

int main()
{
  int sum{0};

  // Write the loop here.

  std::cout << "Sum of 10 to 20 = " << sum << '\n';
}
