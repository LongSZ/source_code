#include <iostream>
int main() {
int x, sum{}, count{};
#include "snip1306.hh"
std::cout << sum << '\n' << count << '\n';
}
