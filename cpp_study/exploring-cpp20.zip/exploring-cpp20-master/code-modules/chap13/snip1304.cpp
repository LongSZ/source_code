#include <iostream>
int main() {
#include "snip1304.hh"
}
