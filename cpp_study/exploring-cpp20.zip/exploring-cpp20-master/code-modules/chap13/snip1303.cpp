#include <iostream>
int main() {
int x;
int sum{};
#include "snip1303.hh"
std::cout << sum << '\n';
}
