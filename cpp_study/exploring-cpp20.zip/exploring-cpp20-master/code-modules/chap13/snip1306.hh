/** @file snip1306.hh */
/** Code Snippet 13-6 */
while (std::cin >> x)
{
    sum = sum + x;
    ++count;
}
