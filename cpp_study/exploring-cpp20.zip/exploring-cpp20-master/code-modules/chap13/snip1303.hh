/** @file snip1303.hh */
/** Code Snippet 13-3 */
while (std::cin >> x)
  sum = sum + x;
