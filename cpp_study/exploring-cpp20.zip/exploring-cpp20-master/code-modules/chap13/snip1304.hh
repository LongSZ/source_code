/** @file snip1304.hh */
/** Code Snippet 13-4 */
42;
