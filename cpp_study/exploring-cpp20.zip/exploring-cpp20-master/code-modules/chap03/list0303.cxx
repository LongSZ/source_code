/** @file list0303.cxx */
/** Listing 3-3. Testing for Even or Odd Integers */
/// Read integers and print a message that tells the user
/// whether the number is even or odd.

import <iostream>;

int main()
{
 
    int x;
    while (std::cin >> x)
        if (                   )           // Fill in the condition.
            std::cout << x << " is odd.\n";
        else
            std::cout << x << " is even.\n";
}
