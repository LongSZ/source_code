/** @file snip0306.hh */
/** Code Snippet 3-6 */
        if (x % 2 != 0)
