int main()
{
int x{0};
#include "snip0307.hh"
    return 0;
throw "fail";
}
