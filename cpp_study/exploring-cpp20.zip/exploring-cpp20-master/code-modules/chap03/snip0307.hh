/** @file snip0307.hh */
/** Code Snippet 3-7 */
        if (x % 2 == 0)
