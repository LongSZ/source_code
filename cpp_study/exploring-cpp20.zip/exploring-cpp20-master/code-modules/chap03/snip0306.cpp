int main()
{
int x{1};
#include "snip0306.hh"
    return 0;
throw "fail";
}
