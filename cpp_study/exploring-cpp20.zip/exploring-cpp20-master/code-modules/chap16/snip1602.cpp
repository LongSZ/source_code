#include <map>
#include <string>
#include "snip1602.hh"
int main() {
}
