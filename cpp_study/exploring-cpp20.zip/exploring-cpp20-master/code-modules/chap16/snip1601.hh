/** @file snip1601.hh */
/** Code Snippet 16-1 */
typedef std::map<std::string,int>::iterator count_iter;
typedef int height;
