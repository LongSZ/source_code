#include <map>
#include <string>
#include "snip1601.hh"
int main() {
}
