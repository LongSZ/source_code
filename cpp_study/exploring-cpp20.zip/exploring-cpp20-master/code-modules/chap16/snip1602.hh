/** @file snip1602.hh */
/** Code Snippet 16-2 */
using count_iter = std::map<std::string, int>;
using height = int;
