#include <format>
#include <iostream>
int main() {
double large_number{ 1.23456789e20 };
double small_number{ 123.456 };
double number_in_general_format { 42.0 };
#include "snip2704.hh"
}
