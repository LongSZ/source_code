#include <format>
#include <iomanip>
#include <iostream>
int main() {
#include "snip2703.hh"
}
