#include <iostream>
void function() {
#include "snip2002.hh"
}
int main() {
  function();
}
