int forty_two() {
#include "snip2001.hh"
}
int main() {
  return forty_two() == 0;
}
