/** @file snip2002.hh */
/** Code Snippet 20-2 */
return;
