/** @file snip2001.hh */
/** Code Snippet 20-1 */
return 42;
