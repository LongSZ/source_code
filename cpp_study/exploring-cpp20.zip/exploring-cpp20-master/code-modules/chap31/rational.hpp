#ifndef RATIONAL_HPP_
#define RATIONAL_HPP_

#include "rational_class.hpp"
#include "rational_equality.hpp"
#include "list3103.hh"
#include "list3104.hh"

#endif
