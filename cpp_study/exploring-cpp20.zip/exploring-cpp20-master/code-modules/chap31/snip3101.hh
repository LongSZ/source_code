/** @file snip3101.hh */
/** Code Snippet 31-1 */
TEST(rational{2, 2} == rational{5, 5});
TEST(rational{6,3} > rational{10, 6});
