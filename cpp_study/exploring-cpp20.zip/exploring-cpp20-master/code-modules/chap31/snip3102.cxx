/** @file snip3102.cxx */
/** Code Snippet 31-2 */
int a(3.14); // which one is okay,
int b{3.14}; // and which is an error?
