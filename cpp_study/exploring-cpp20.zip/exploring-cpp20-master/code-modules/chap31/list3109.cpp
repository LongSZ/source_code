#include <cassert>
#include <iostream>
#include <numeric>
#include "list3109.hh"
int main() {
   rational pi(3.1415926535897932);
   std::cout << pi.numerator << '/' << pi.denominator << '\n';
}
