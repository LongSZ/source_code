#include "test.hpp"
#include "rational.hpp"
int main() {
#include "snip3101.hh"
}
