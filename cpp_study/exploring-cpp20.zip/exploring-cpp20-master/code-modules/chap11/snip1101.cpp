#include <vector>
int main() {
using vi =
#include "snip1101.hh"
;
return sizeof(vi) == 0;
}
