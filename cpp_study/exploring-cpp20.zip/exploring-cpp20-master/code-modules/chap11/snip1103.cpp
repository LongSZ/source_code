#include <vector>
int main() {
std::vector<int> data{0};
#include "snip1103.hh"
return right == data.begin();
}
