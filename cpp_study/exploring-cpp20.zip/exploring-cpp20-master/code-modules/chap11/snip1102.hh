/** @file snip1102.hh */
/** Code Snippet 11-2 */
auto left{ data.begin() };
