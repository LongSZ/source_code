/** @file snip1101.hh */
/** Code Snippet 11-1 */
std::vector<int>::iterator
