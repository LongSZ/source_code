#include <vector>
int main() {
std::vector<int> data{0};
#include "snip1102.hh"
return left == data.end();
}
