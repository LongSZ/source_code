/** @file snip1103.hh */
/** Code Snippet 11-3 */
auto right{ data.end() };
