/** @file snip1105.hh */
/** Code Snippet 11-5 */
std::iter_swap(left, right);
