#include <algorithm>
#include <vector>
int main() {
std::vector<int> data{ 0 };
#include "snip1102.hh"
#include "snip1103.hh"
#include "snip1105.hh"
}
