int main() {
#include "snip2803.hh"
}
