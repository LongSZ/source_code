/** @file snip2804.hh */
/** Code Snippet 28-4 */
double const c = 299792458.0;            ///< speed of light in m/sec
