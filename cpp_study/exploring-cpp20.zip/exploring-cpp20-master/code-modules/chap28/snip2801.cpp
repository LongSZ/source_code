int main() {
#include "snip2801.hh"
}
