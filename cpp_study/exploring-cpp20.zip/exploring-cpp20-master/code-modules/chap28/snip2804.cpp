int main() {
#include "snip2804.hh"
return static_cast<int>(c - c);
}
