var searchData=
[
  ['palindromes',['Palindromes',['../index.html',1,'']]]
];
