int main() {
#include "snip2802.hh"
}
