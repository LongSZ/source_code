/** @file snip0803.hh */
/** Code Snippet 8-3 */
std::format("x: {2}, y: {1}, z: {0}\n", 10, 20, 30)
