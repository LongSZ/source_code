/** @file list0801.cxx */
/** Listing 8-1. Print a Table of Squares and Cubes  */
import <iomanip>;
import <iostream>;

int main()
{
  std::cout << " N   N^2    N^3\n";
  for (int i{1}; i != 21; ++i)
  {
    // write the loop body here
  }
}
