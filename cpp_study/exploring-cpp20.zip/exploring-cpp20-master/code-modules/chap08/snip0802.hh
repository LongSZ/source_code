/** @file snip0802.hh */
/** Code Snippet 8-2 */
std::format("x: {}, y: {}, z: {}\n", 10, 20, 30)
