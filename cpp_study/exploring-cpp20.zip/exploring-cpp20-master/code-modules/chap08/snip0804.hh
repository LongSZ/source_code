/** @file snip0804.hh */
/** Code Snippet 8-4 */
std::format("'{0:c}': {0:#04x} {0:0>#10b} |{0:{1}d}| {2:s}\n", '*', 4, "str")
