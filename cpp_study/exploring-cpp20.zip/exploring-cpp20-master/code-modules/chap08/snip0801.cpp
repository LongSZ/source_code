#include <iomanip>
#include <iostream>
int main() {
int i{42};
#include "snip0801.hh"
}
