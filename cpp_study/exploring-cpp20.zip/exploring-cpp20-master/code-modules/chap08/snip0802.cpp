#include <format>
#include <iostream>
int main() {
std::cout <<
#include "snip0802.hh"
;
}
