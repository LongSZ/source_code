/** @file snip0801.hh */
/** Code Snippet 8-1 */
    std::cout << std::setw(6) << i
              << std::setw(6) << i*i
              << std::setw(6) << i*i*i
              << '\n';
