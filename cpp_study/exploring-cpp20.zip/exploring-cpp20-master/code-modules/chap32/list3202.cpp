#include <sstream>
#include "rational.hpp"
#include "list3202.hh"
int main() {

}
