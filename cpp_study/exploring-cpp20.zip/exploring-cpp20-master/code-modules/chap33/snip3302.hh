/** @file snip3302.hh */
/** Code Snippet 33-2 */
rational(rational const&) = default;
