void reduce() {}
#include "list3301.hh"
int main() {

}
