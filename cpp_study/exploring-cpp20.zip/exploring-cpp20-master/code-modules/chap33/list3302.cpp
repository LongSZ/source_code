class rational {
#include "list3302.hh"
int numerator;
int denominator;
void reduce() {}
};
int main() {

}
