/** @file list3304.hh */
/** Listing 33-4. Overloaded Constructors for rational */
rational()
: rational{0, 1}
{}

