class rational {
#include "list3303.hh"
int numerator, denominator;
};
int main() {

}
