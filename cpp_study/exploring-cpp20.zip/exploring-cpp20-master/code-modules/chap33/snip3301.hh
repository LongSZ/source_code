/** @file snip3301.hh */
/** Code Snippet 33-1 */
rational& operator=(rational const&) = default;
