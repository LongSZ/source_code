class rational {
#include "snip3302.hh"
};
int main() {
}
