class rational {
#include "snip3301.hh"
};
int main() {
}
