class rational {
#include "list3304.hh"
rational(int,int) {}
};
int main() {

}
