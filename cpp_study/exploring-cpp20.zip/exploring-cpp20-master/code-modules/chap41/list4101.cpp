#include <cassert>
#include <numeric>
#include "list4101.hh"
int main() {

}
