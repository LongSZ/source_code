#include <cassert>
#include <numeric>
#include "list4102.hh"
int main() {

}
