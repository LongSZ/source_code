#include <iostream>
#include <string>
#include <string_view>

#include "list3901.hh"
#include "list3903.hh"
#include "list3906.hh"
int main() {
#include "snip3902.hh"
std::cout << nuts << '\n';
std::cout << w << '\n';
}
