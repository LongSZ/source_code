#include <map>
#include <string>
int main() {
#include "snip1501.hh"
#include "snip1502.hh"
}
