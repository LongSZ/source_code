#include <map>
#include <string>
int main() {
#include "snip1501.hh"
return counts.size();
}
