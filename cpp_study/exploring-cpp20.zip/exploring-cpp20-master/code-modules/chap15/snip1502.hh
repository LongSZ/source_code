/** @file snip1502.hh */
/** Code Snippet 15-2 */
counts["something"] = 0;
