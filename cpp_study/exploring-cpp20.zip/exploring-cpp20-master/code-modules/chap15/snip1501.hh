/** @file snip1501.hh */
/** Code Snippet 15-1 */
std::map<std::string, int> counts;
