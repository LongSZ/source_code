int main() {
int by_value{0}, by_reference{1}, another_by_value{0}, another_by_reference{1};
#include "snip2408.hh"
lambda();
return by_reference + another_by_reference;
}
