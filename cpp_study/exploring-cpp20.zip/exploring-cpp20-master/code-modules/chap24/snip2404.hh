/** @file snip2404.hh */
/** Code Snippet 24-4 */
int forty_two{ times_three(14) };
