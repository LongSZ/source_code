#include <functional>
int main() {
#include "snip2405.hh"
return times_two(0);
}
