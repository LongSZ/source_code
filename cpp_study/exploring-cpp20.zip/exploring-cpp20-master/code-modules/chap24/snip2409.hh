/** @file snip2409.hh */
/** Code Snippet 24-9 */
[](int i) -> int { return i * 2; }
