int main() {
#include "snip2403.hh"
return times_three(0);
}
