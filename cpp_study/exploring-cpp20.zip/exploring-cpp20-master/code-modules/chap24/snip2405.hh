/** @file snip2405.hh */
/** Code Snippet 24-5 */
std::function<int(int)> times_two{ [](int i) { return i * 2; } };
