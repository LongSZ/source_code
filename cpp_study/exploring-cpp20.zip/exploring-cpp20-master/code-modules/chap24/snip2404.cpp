int main() {
#include "snip2403.hh"
#include "snip2404.hh"
return forty_two - forty_two;
}
