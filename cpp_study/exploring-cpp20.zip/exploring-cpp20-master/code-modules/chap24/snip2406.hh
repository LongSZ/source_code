/** @file snip2406.hh */
/** Code Snippet 24-6 */
[&multiplier](int i) { return i * multiplier; };
