int main() {
#include "snip2407.hh"
capture_all_by_reference();
return capture_all_by_value();
}
