/** @file snip2403.hh */
/** Code Snippet 24-3 */
auto times_three = [](int i) { return i * 3; };
