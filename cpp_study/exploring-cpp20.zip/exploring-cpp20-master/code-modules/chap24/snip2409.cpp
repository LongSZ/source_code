int main() {
auto lambda =
#include "snip2409.hh"
;

return lambda(0);
}
