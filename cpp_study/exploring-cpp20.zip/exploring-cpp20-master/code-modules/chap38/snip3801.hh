/** @file snip3801.hh */
/** Code Snippet 38-1 */

