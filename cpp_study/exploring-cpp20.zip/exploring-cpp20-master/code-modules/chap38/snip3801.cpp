#include <iostream>
int main() {
#include "snip3801.hh"
}
