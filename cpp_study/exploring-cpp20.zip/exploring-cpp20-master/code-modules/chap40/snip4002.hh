/** @file snip4002.hh */
/** Code Snippet 40-2 */
std::string source{"string"};
std::string target{std::move(source)};
