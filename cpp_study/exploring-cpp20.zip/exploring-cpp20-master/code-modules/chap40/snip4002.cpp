#include <iostream>
#include <string>
int main() {
#include "snip4002.hh"
std::cout << target << '\n';
}
