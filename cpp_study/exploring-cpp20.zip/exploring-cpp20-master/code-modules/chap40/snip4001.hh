/** @file snip4001.hh */
/** Code Snippet 40-1 */
std::string source{"string"}, target{};
target = std::move(source);
