struct rational {
#include "snip3002.hh"
int numerator, denominator;
};

int main() {

}
