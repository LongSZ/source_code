/** @file snip3002.hh */
/** Code Snippet 30-2 */
rational(int num)
: numerator{num}, denominator{1}
{}
