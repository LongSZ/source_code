/** @file snip3001.hh */
/** Code Snippet 30-1 */
rational(int num) : rational{num, 1} {}
