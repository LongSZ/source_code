class rational {
rational(int,int) {}
#include "snip3001.hh"
};
int main() {

}
