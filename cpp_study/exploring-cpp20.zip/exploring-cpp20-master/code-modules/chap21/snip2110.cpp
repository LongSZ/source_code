#include <iostream>
#include <string_view>
void ignore_line() {}
#include "snip2110.hh"
int main() {

}
