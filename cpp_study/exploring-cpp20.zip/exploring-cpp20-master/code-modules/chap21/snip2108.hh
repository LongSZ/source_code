/** @file snip2108.hh */
/** Code Snippet 21-8 */
int triple(int const& x)
