/** @file snip2106.hh */
/** Code Snippet 21-6 */
int const max_width{80}; // maximum line width before wrapping
