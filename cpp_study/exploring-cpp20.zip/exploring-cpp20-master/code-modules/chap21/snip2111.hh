/** @file snip2111.hh */
/** Code Snippet 21-11 */
void read_numbers(int& x, int& y)
{
  std::cin >> x >> y;
}
