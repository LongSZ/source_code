#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
#include "snip2103.hh"
int main() {

}
