#include "snip2108.hh"
;
int main() {

}
