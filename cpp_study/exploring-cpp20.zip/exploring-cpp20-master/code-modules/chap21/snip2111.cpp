#include <iostream>
#include "snip2111.hh"
int main() {

}
