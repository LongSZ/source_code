/** @file snip2107.hh */
/** Code Snippet 21-7 */
v.emplace_back(10); // add an element
v.pop_back();    // remove the last element
v.front() = 42;  // modify an element
