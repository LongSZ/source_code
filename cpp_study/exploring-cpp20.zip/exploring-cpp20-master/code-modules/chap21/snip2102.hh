/** @file snip2102.hh */
/** Code Snippet 21-2 */
data = add(data, 42);
