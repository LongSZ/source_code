#include <vector>
#include "snip2104.hh"
;

int main() {

}
