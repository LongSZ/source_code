/** @file snip2105.hh */
/** Code Snippet 21-5 */
const int max_width{80}; // maximum line width before wrapping
