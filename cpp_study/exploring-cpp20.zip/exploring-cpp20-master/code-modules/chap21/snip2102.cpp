#include <vector>
#include "snip2101.hh"
int main() {
std::vector<int> data;
#include "snip2102.hh"
}
