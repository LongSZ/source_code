#include <iostream>
#include <string>
#include <vector>
#include "snip2109.hh"
int main() {

}
