#include <vector>
int main() {
std::vector<int> v{ 1,2,3 };
#include "snip2107.hh"
}
