#include <vector>
#include "snip2101.hh"
int main() {
}
