int main() {
#include "snip2106.hh"
return max_width - 80;
}
