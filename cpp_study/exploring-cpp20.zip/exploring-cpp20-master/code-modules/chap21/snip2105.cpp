int main() {
#include "snip2105.hh"
return max_width - 80;
}
