/** @file snip2104.hh */
/** Code Snippet 21-4 */
void print_vector(const std::vector<int>& v)
