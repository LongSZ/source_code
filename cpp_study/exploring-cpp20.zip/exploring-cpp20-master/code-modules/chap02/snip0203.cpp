#include <iostream>
int main()
{
#include "snip0203.hh"
std::cout << '\n';
}
