/** @file list0202.hh */
/** Listing 2-2. Demonstrating Comment Styles and Nesting */
/* Start of a comment /* start of comment characters are not special in a comment
 // still in a comment
 Still in a comment
*/
no_longer_in_a_comment();
// Start of a comment /* start of comment characters are not special in a comment
no_longer_in_a_comment();
