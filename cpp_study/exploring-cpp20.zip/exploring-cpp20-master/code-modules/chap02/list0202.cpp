void no_longer_in_a_comment() {}
int main() {
#include "list0202.hh"
}
