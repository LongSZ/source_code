/** @file snip0203.hh */
/** Code Snippet 2-3 */
std::cout << "not quoted; \"in quotes\", not quoted";
