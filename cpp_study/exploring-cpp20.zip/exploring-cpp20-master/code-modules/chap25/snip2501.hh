/** @file snip2501.hh */
/** Code Snippet 25-1 */
std::sort(start, end);
std::sort(start, end, compare);
