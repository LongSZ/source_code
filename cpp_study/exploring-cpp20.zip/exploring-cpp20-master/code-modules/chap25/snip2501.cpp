#include <algorithm>
#include <vector>

int compare(int a, int b)
{
  return b < a;
}

int main() {
std::vector<int> data{ 2, 3, 1 };
auto start{ data.begin() };
auto end{ data.end() };
#include "snip2501.hh"
}
