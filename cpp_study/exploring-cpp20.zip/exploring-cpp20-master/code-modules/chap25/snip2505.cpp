#include <vector>
int main() {
std::vector<int> container_full_of_big_things;
#include "snip2505.hh"
if (big_item)
return 0;
}
