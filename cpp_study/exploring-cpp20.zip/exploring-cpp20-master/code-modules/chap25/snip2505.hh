/** @file snip2505.hh */
/** Code Snippet 25-5 */
for (auto const& big_item : container_full_of_big_things)
