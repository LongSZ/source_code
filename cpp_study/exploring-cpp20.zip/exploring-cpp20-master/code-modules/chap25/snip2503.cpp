#include <locale>
int main() {
return not
#include "snip2503.hh"
}
