/** @file snip2503.hh */
/** Code Snippet 25-3 */
std::isalpha('X', std::locale{""});
