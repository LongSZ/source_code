/** @file snip2502.hh */
/** Code Snippet 25-2 */
std::isalpha('X', std::locale{});
