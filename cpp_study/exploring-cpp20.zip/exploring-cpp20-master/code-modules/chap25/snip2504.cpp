#include <vector>
int main() {
std::vector<int> data;
#include "snip2504.hh"
return data.size() == 0;
}
