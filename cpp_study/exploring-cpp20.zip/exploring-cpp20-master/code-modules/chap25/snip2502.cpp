#include <locale>
int main() {
return not
#include "snip2502.hh"
}
