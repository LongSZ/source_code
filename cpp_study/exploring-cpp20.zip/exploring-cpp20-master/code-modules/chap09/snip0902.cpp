#include <iostream>
#include <vector>
int main() {
std::vector<int> data{ 10, 20, 30 };
return
#include "snip0902.hh"
;
}
