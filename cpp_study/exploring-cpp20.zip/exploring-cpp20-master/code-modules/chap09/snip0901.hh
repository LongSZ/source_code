/** @file snip0901.hh */
/** Code Snippet 9-1 */
for (std::vector<int>::iterator iter{data.begin()}; iter != data.end(); ++iter){ int element = *iter; std::cout << element << '\n'; }
