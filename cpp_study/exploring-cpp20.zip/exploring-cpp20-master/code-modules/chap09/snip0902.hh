/** @file snip0902.hh */
/** Code Snippet 9-2 */
data.begin() == data.end()
