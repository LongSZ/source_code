#include <iostream>
#include <vector>
int main() {
std::vector<int> data{ 10, 20, 30 };
#include "snip0901.hh"
}
