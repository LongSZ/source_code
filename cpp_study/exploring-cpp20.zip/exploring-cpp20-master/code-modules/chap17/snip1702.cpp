#include <iostream>
int main() {
#include "snip1702.hh"
std::cout << left << right << '\n';
}
