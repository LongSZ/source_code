/** @file snip1701.hh */
/** Code Snippet 17-1 */
'0' + 7 == '7'
