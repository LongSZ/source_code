#include <iostream>
int main() {
return not(
#include "snip1701.hh"
);
}
