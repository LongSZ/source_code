/** @file snip1702.hh */
/** Code Snippet 17-2 */
// Skip white space, then read two adjacent characters.
char left, right;
std::cin >> left >> std::noskipws >> right >> std::skipws;
