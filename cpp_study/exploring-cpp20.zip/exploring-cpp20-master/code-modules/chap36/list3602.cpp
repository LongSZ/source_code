#include <cmath>
#include "list3602.hh"
int main() {

}
