class point {
#include "snip3601.hh"

void move_polar(double,double) {}
void move_cartesian(double,double) {}
};
int main() {

}
