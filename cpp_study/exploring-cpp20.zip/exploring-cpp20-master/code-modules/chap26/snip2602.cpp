int main() {
#include "snip2602.hh"
return lots_o_bits - lots_o_bits;
}
