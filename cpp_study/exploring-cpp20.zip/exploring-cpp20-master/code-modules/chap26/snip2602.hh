/** @file snip2602.hh */
/** Code Snippet 26-2 */
long lots_o_bits{2147483647};
