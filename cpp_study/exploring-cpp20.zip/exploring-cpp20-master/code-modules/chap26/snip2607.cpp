#include <iostream>
int main() {
#include "snip2607.hh"
std::cout << '\n';
}
