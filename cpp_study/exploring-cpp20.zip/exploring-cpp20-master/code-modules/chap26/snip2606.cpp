int main() {
for(
#include "snip2606.hh"
)
if (x) return 0;
}
