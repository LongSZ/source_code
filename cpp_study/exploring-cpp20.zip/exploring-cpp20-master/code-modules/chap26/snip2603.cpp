int main() {
#include "snip2603.hh"
return answer * zero;
}
