/** @file snip2604.hh */
/** Code Snippet 26-4 */
using byte = signed char;
