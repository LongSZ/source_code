#include "snip2604.hh"
int main() {
}
