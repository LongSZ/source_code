/** @file snip2603.hh */
/** Code Snippet 26-3 */
short int answer{42};
short zero{0};
