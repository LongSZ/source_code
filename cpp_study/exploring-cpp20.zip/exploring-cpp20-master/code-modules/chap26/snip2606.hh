/** @file snip2606.hh */
/** Code Snippet 26-6 */
int x{42};
static_cast<short>(x);
