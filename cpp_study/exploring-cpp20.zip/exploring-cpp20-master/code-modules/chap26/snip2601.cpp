int main() {
#include "snip2601.hh"
return lots_o_bits - lots_o_bits;
}
