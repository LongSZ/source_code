/** @file snip2601.hh */
/** Code Snippet 26-1 */
long int lots_o_bits{2147483647};
