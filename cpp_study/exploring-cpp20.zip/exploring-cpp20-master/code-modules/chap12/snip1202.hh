/** @file snip1202.hh */
/** Code Snippet 12-2 */
std::cout << std::format("{} {:d}\n", a, b);
