#include <format>
#include <iostream>
int main() {
bool a{true}, b{false};
#include "snip1202.hh"
}
