#include <iostream>
int main() {
#include "snip1201.hh"
std::cout << '\n';
}
