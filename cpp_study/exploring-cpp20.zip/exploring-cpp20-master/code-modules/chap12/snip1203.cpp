#include <iostream>
int main() {
#include "snip1203.hh"
}
