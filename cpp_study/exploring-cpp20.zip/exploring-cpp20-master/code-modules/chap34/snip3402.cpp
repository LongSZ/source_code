#include <vector>
int main() {
#include "snip3402.hh"
return data[0] - 1;
}
