#include <vector>
int main() {
#include "snip3403.hh"
return ten_zeroes[0];
}
