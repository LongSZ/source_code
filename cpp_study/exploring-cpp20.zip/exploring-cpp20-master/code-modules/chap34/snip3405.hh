/** @file snip3405.hh */
/** Code Snippet 34-5 */
point pt1;          // default constructor
point p2{pt1};      // copy constructor
