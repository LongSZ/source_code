/** @file snip3402.hh */
/** Code Snippet 34-2 */
std::vector<int> data{ 1, 2, 3 };
