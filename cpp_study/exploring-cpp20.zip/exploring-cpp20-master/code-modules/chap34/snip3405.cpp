#include "snip3404.hh"
int main() {
#include "snip3405.hh"
return p2.x_;
}
