/** @file list3401.hh */
/** Listing 34-1. Class Definition for a Cartesian Point */
struct point
{
  double x;
  double y;
};
