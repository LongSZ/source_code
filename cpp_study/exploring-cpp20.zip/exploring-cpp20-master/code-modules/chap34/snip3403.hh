/** @file snip3403.hh */
/** Code Snippet 34-3 */
std::vector<int> ten_zeroes(10, 0);
