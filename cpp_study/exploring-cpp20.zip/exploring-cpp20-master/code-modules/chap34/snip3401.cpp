#include "snip3401.hh"
int main() {

}
