#include <iostream>
#include "snip3407.hh"
int main() {

}
