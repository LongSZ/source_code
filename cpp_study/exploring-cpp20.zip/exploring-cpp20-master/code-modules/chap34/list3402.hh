/** @file list3402.hh */
/** Listing 34-2. Multiple Data Members in One Declaration */
struct point
{
  double x, y;
};
