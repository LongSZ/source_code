#include <iostream>
#include "snip3404.hh"
int main() {

}
