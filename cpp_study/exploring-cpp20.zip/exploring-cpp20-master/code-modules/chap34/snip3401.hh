/** @file snip3401.hh */
/** Code Snippet 34-1 */
struct point {
  int x = 1;
  int y;
  point() {} // initializes x to 1 and y to 0
};
