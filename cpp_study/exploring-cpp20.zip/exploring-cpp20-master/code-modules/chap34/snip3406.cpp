#include <iostream>
#include "snip3406.hh"
int main() {

}
