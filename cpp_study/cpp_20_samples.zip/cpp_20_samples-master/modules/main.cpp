// Import our greeter module
import hello;

int main() {
  greeter("world");
  return 0;
}
