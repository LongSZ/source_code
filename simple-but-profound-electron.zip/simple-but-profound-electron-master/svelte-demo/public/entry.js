'use strict';

var electron = require('electron');

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = "true";
class App {
    createWindow() {
        this.win = new electron.BrowserWindow({
            width: 800,
            height: 600,
            frame: false,
            webPreferences: {
                nodeIntegration: true,
                nodeIntegrationInWorker: true,
                nodeIntegrationInSubFrames: true,
                enableRemoteModule: true,
                allowRunningInsecureContent: true,
                webSecurity: false,
                enableWebSQL: false,
                spellcheck: false,
                contextIsolation: false,
            },
        });
        this.win.loadURL("http://localhost:5916/");
        this.win.maximize();
        this.win.webContents.openDevTools({ mode: "undocked" });
    }
    sendSizeChangeMsg() {
        let bounds = this.win.getBounds();
        let msg = {
            width: bounds.width,
            height: bounds.height,
            isMaximized: this.win.isMaximized(),
        };
        this.win.webContents.send("windowResize", msg);
    }
    initEvent() {
        this.win.on("maximize", (e) => this.sendSizeChangeMsg());
        this.win.on("unmaximize", (e) => this.sendSizeChangeMsg());
        this.win.on("resized", (e) => this.sendSizeChangeMsg());
    }
    initHandle() {
        electron.ipcMain.handle("windowToolCall", (e, param) => {
            if (param == "maxsize")
                this.win.maximize();
            else if (param == "minisize")
                this.win.minimize();
            else if (param == "restore")
                this.win.unmaximize();
            else if (param == "close")
                this.win.close();
        });
    }
    async start() {
        await electron.app.whenReady();
        this.createWindow();
        this.initEvent();
        this.initHandle();
        // this.win.loadURL("https://www.baidu.com/");
    }
}
globalThis.entry = new App();
globalThis.entry.start();
//# sourceMappingURL=entry.js.map
