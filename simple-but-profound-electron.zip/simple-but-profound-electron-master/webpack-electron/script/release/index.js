let fs = require("fs");
let path = require("path");
let webpack = require("webpack");
let HtmlWebpackPlugin = require("html-webpack-plugin");
let { CleanWebpackPlugin } = require("clean-webpack-plugin");
let { merge } = require("webpack-merge");
let baseConfig = require("../common/baseConfig.js");

let release = {
  injectEnvScript() {
    let env = require("./env.js");
    let script = "";
    for (let v in env) {
      script += `process.env.${v}="${env[v]}";`;
    }
    script += `process.env.RES_DIR = process.resourcesPath;`;
    let outfile = path.join(process.cwd(), "release/bundled/entry.js");
    let js = `${script}${fs.readFileSync(outfile)}`;
    fs.writeFileSync(outfile, js);
  },
  buildMain() {
    let config = merge(baseConfig, {
      entry: { entry: path.join(process.cwd(), "./src/main/app.ts") },
      plugins: [new CleanWebpackPlugin()],
      output: {
        filename: "entry.js",
        path: path.join(process.cwd(), "release/bundled"),
      },
      mode: "production",
    });
    return new Promise((resolve, reject) => {
      webpack(config).run((err, stats) => {
        if (err) {
          console.log(err);
          rejects(err);
          return;
        }
        if (stats.hasErrors()) {
          reject(stats);
          return;
        }
        this.injectEnvScript();
        resolve();
      });
    });
  },
  getRendererObj() {
    let result = { entry: {}, plugins: [] };
    let rendererPath = path.join(process.cwd(), "src/renderer");
    let rendererFiles = fs.readdirSync(rendererPath);
    for (let fileName of rendererFiles) {
      let plainName = path.basename(fileName, ".html");
      result.entry[plainName] = `./src/renderer/${plainName}/index.ts`;
      result.plugins.push(
        new HtmlWebpackPlugin({
          chunks: [plainName],
          template: `./src/renderer/${plainName}.html`,
          filename: `${plainName}.html`,
          minify: true,
        })
      );
    }
    return result;
  },
  buildRenderer() {
    let rendererObj = this.getRendererObj();
    let config = merge(baseConfig, {
      entry: rendererObj.entry,
      plugins: rendererObj.plugins,
      output: {
        filename: "[name].bundle.js",
        path: path.join(process.cwd(), "release/bundled"),
      },
      mode: "production",
    });
    return new Promise((resolve, reject) => {
      webpack(config).run((err, stats) => {
        if (err) {
          console.log(err);
          rejects(err);
          return;
        }
        if (stats.hasErrors()) {
          reject(stats);
          return;
        }
        resolve();
      });
    });
  },
  buildInstaller() {
    let options = {
      config: {
        directories: {
          output: path.join(process.cwd(), "release"),
          app: path.join(process.cwd(), "release/bundled"),
        },
        files: ["**"],
        extends: null,
        productName: "yourProductName",
        appId: "com.yourComp.yourProduct",
        asar: true,
        extraResources: require("../common/extraResources.js"),
        win: require("../common/winConfig.js"),
        mac: require("../common/macConfig.js"),
        nsis: require("../common/nsisConfig.js"),
        publish: [{ provider: "generic", url: "" }],
      },
      project: process.cwd(),
    };
    let builder = require("electron-builder");
    return builder.build(options);
  },
  buildModule() {
    let pkgJsonPath = path.join(process.cwd(), "package.json");
    let localPkgJson = JSON.parse(fs.readFileSync(pkgJsonPath, "utf-8"));
    let electronConfig = localPkgJson.devDependencies.electron.replace("^", "");
    delete localPkgJson.scripts;
    delete localPkgJson.devDependencies;
    localPkgJson.main = "entry.js";
    localPkgJson.devDependencies = { electron: electronConfig };
    fs.writeFileSync(
      path.join(process.cwd(), "release/bundled/package.json"),
      JSON.stringify(localPkgJson)
    );
    fs.mkdirSync(path.join(process.cwd(), "release/bundled/node_modules"));
  },
  async start() {
    await this.buildMain();
    await this.buildRenderer();
    this.buildModule();
    this.buildInstaller();
  },
};
release.start();
