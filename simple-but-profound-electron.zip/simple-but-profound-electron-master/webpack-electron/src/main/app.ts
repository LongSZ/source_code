import { app, BrowserWindow, protocol } from "electron";
import path from "path";
import fs from "fs";
import test from "./test";

protocol.registerSchemesAsPrivileged([
  {
    scheme: "app",
    privileges: {
      standard: true,
      supportFetchAPI: true,
      secure: true,
      corsEnabled: true,
    },
  },
]);
let mainWindow;
let log = (str) => {
  fs.appendFileSync(`d:\\log.txt`, str + "\r\n");
};
app.on("ready", () => {
  protocol.registerBufferProtocol("app", (request, response) => {
    let pathName = new URL(request.url).pathname;
    let extension = path.extname(pathName).toLowerCase();
    if (!extension) return;
    pathName = decodeURI(pathName);
    log(pathName);
    let filePath = path.join(process.resourcesPath, "app.asar", pathName);
    log(filePath);
    fs.readFile(filePath, (error, data) => {
      if (error) return;
      let mimeType = "";
      if (extension === ".js") {
        mimeType = "text/javascript";
      } else if (extension === ".html") {
        mimeType = "text/html";
      } else if (extension === ".css") {
        mimeType = "text/css";
      } else if (extension === ".svg") {
        mimeType = "image/svg+xml";
      } else if (extension === ".json") {
        mimeType = "application/json";
      }
      log(data);
      response({ mimeType, data });
    });
  });
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      webSecurity: false,
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  if (app.isPackaged) {
    log("app://./index.html");
    mainWindow.loadURL(`app://./index.html`);
    // mainWindow.loadURL(`https://www.baidu.com`);
  } else {
    mainWindow.loadURL(`http://localhost:${process.env.WEB_PORT}/`);
  }
  //   console.log(test);
  log(JSON.stringify(test));
});
