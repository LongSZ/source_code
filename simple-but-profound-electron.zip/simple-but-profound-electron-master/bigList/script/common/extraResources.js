module.exports = {
  from: "./resource/release",
  to: "./",
};
