module.exports = {
  APP_VERSION: require("../../package.json").version,
  ENV_NOW: "production",
  PROTOBUF_SERVER: "******.com",
  SENTRY_SERVICE: "https://******.com/34",
  ELECTRON_DISABLE_SECURITY_WARNINGS: true,
};
