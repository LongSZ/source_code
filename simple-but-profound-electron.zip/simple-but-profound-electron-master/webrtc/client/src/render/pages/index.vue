<template>
  <div>首页</div>
</template>
<script lang="ts">
export default {};
</script>
