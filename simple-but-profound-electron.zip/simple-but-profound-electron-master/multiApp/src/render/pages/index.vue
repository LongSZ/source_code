<template>
  <div>成功了</div>
</template>
<script lang="ts">
export default {};
</script>
