var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) =>
  __defProp(target, "__esModule", { value: true });
var __reExport = (target, module2, desc) => {
  if (
    (module2 && typeof module2 === "object") ||
    typeof module2 === "function"
  ) {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, {
          get: () => module2[key],
          enumerable:
            !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable,
        });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(
    __markAsModule(
      __defProp(
        module2 != null ? __create(__getProtoOf(module2)) : {},
        "default",
        module2 && module2.__esModule && "default" in module2
          ? { get: () => module2.default, enumerable: true }
          : { value: module2, enumerable: true }
      )
    ),
    module2
  );
};

// src/main/app.ts
var import_electron = __toModule(require("electron"));

// src/main/WebPreferencesConfig.ts
var WebPreferencesConfig = class {
  constructor() {
    this.nodeIntegration = true;
    this.devTools = true;
    this.webSecurity = false;
    this.nodeIntegrationInSubFrames = true;
    this.nodeIntegrationInWorker = true;
    this.worldSafeExecuteJavaScript = true;
    this.contextIsolation = false;
    this.center = true;
  }
};

// src/main/WindowConfig.ts
var WindowConfig = class {
  constructor() {
    this.frame = false;
    this.show = false;
    this.webPreferences = new WebPreferencesConfig();
    this.nodeIntegrationInSubFrames = true;
    this.nativeWindowOpen = true;
    this.movable = true;
    this.thickFrame = true;
  }
};

// src/main/app.ts
import_electron.app.commandLine.appendSwitch("--disable-site-isolation-trials");
var App = class {
  constructor() {
    this.winCanBeClosedFlag = false;
    import_electron.app.on("ready", async () => {
      this.createWindow();
    });
    import_electron.app.on("window-all-closed", async () => {
      console.log("window-all-closed");
      import_electron.app.quit();
    });
    import_electron.app.on("before-quit", async () => {
      console.log("before-quit");
    });
    import_electron.app.on("will-quit", async () => {
      console.log("will-quit");
    });
    import_electron.app.on("quit", async () => {
      console.log("quit");
    });
  }
  createWindow() {
    let config = new WindowConfig();
    config.frame = true;
    config.width = 1024;
    config.height = 800;
    config.show = true;
    this.win = new import_electron.BrowserWindow(config);
    this.win.loadURL(`http://localhost:900/#index`);
    this.win.on("close", async (e) => {
      console.log("win close");
      if (!this.winCanBeClosedFlag) {
        e.preventDefault();
        let choice = await import_electron.dialog.showMessageBox(this.win, {
          title: "do you want to close",
          message:
            "\u4F60\u786E\u5B9A\u8981\u5173\u95ED\u7A97\u53E3\u5417\uFF1F",
          buttons: ["\u5426", "\u662F"],
        });
        if (choice.response == 1) {
          this.winCanBeClosedFlag = true;
          this.win.close();
          return;
        }
      }
      this.winCanBeClosedFlag = false;
    });
    this.win.on("closed", () => {
      console.log("win closed");
    });
  }
};
globalThis.appEntry = new App();
//# sourceMappingURL=entry.js.map
