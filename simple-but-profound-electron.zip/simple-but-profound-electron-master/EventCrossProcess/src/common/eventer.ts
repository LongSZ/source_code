let events = require("events");
let { ipcRenderer, ipcMain, webContents } = require("electron");
let crypto = require("crypto");
class Eventer {
  private instance;
  emit(eventName, eventArgs) {
    let rnd = crypto.randomBytes(6).toString("hex");
    let now = Date.now();
    let name = `eventerEx${now}${rnd}`;
    let dataStr = JSON.stringify({ eventName, eventArgs });
    localStorage.setItem(name, dataStr);
    this.instance.emit(eventName, eventArgs);
  }
  on(eventName, callBack) {
    this.instance.on(eventName, callBack);
  }
  storageListener() {
    window.addEventListener("storage", (e) => {
      if (e.storageArea != localStorage) return;
      if (e.key && !e.key.startsWith("eventerEx")) return;
      if (!e.newValue) return;
      let dataStr = localStorage.getItem(e.key);
      let data = JSON.parse(dataStr);
      this.instance.emit(data.eventName, data.eventArgs);
      localStorage.removeItem(e.key);
    });
  }
  constructor() {
    this.instance = new events.EventEmitter();
    this.instance.setMaxListeners(Infinity);
    this.storageListener();
  }
}
export let eventer = new Eventer();

// class Eventer {
//   private instance;
//   emit(eventName, eventArgs) {
//     this.instance.emit(eventName, eventArgs);
//     if (ipcMain) {
//       webContents.getAllWebContents().forEach((wc) => {
//         wc.send("__eventPipe", { eventName, eventArgs });
//       });
//     }
//     if (ipcRenderer) {
//       ipcRenderer.invoke("__eventPipe", { eventName, eventArgs });
//     }
//   }
//   on(eventName, callBack) {
//     this.instance.on(eventName, callBack);
//   }
//   initEventPipe() {
//     if (ipcRenderer) {
//       ipcRenderer.on("__eventPipe", (e, { eventName, eventArgs }) => {
//         this.instance.emit(eventName, eventArgs);
//       });
//     }
//     if (ipcMain) {
//       ipcMain.handle("__eventPipe", (e, { eventName, eventArgs }) => {
//         this.instance.emit(eventName, eventArgs);
//         webContents.getAllWebContents().forEach((wc) => {
//           if (wc.id != e.sender.id) {
//             wc.send("__eventPipe", { eventName, eventArgs });
//           }
//         });
//       });
//     }
//   }
//   constructor() {
//     this.instance = new events.EventEmitter();
//     this.instance.setMaxListeners(Infinity);
//     this.initEventPipe();
//   }
// }
// export let eventer = new Eventer();
