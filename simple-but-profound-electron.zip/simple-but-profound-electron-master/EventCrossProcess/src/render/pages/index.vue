<template>
  <div>成功了Index</div>
</template>
<script lang="ts">
import { onMounted } from "@vue/runtime-core";
import { eventer } from "../../common/eventer";
export default {
  setup() {
    onMounted(() => {
      console.log("on");
      eventer.on("eventName", (arg) => {
        console.log(arg);
      });
    });
  },
};
</script>
