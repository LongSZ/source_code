<template>
  <div>成功了Page</div>
</template>
<script lang="ts">
import { onMounted } from "@vue/runtime-core";
import { eventer } from "../../common/eventer";
export default {
  setup() {
    onMounted(() => {
      setTimeout(() => {
        console.log("emit");
        eventer.emit("eventName", { param: `hello from renderer process` });
      }, 6000);
    });
  },
};
</script>
