<template>
  <router-view />
</template>

<script lang="ts">
export default {
  setup() {},
};
</script>
<style lang="scss"></style>
