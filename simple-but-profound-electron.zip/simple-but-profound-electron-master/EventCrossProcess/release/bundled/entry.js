var __create = Object.create;
var __defProp = Object.defineProperty;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __markAsModule = (target) =>
  __defProp(target, "__esModule", { value: true });
var __exportStar = (target, module2, desc) => {
  __markAsModule(target);
  if (
    (module2 && typeof module2 === "object") ||
    typeof module2 === "function"
  ) {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, {
          get: () => module2[key],
          enumerable:
            !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable,
        });
  }
  return target;
};
var __toModule = (module2) => {
  if (module2 && module2.__esModule) return module2;
  return __exportStar(
    __defProp(
      module2 != null ? __create(__getProtoOf(module2)) : {},
      "default",
      { value: module2, enumerable: true }
    ),
    module2
  );
};

// src/main/app.ts
var electron = __toModule(require("electron"));

// src/main/WebPreferencesConfig.ts
var WebPreferencesConfig = class {
  constructor() {
    this.nodeIntegration = true;
    this.devTools = true;
    this.webSecurity = false;
    this.nodeIntegrationInSubFrames = true;
    this.nodeIntegrationInWorker = true;
    this.worldSafeExecuteJavaScript = true;
    this.contextIsolation = false;
    this.center = true;
  }
};

// src/main/WindowConfig.ts
var WindowConfig = class {
  constructor() {
    this.frame = false;
    this.show = false;
    this.webPreferences = new WebPreferencesConfig();
    this.nodeIntegrationInSubFrames = true;
    this.nativeWindowOpen = true;
    this.movable = true;
    this.thickFrame = true;
  }
};

// src/main/app.ts
electron.app.commandLine.appendSwitch("--disable-site-isolation-trials");
var App = class {
  createWindow() {
    let config = new WindowConfig();
    config.frame = true;
    config.width = 1024;
    config.height = 800;
    config.show = true;
    this.win = new electron.BrowserWindow(config);
    this.win.loadURL(`http://localhost:900/#index`);
  }
  createWindow2() {
    let config = new WindowConfig();
    config.frame = true;
    config.width = 1024;
    config.height = 800;
    config.show = true;
    this.win2 = new electron.BrowserWindow(config);
    this.win2.loadURL(`http://localhost:900/#page`);
  }
  constructor() {
    electron.app.on("ready", async () => {
      this.createWindow();
      this.createWindow2();
    });
  }
};
globalThis.appEntry = new App();
//# sourceMappingURL=entry.js.map
