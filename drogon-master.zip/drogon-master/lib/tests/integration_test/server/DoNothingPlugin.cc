/**
 *
 *  DoNothingPlugin.cc
 *
 */

#include "DoNothingPlugin.h"

using namespace drogon;

void DoNothingPlugin::initAndStart(const Json::Value &config)
{
    /// Initialize and start the plugin
}

void DoNothingPlugin::shutdown()
{
    /// Shutdown the plugin
}
