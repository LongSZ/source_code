#include <filesystem>

int main()
{
    std::filesystem::path aPath("../");
    return 0;
}
